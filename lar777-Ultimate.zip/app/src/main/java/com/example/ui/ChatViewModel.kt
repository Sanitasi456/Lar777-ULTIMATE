package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.Content
import com.example.api.GenerateContentRequest
import com.example.api.GenerationConfig
import com.example.api.InlineData
import com.example.api.InstructionCompiler
import com.example.api.Part
import com.example.api.RetrofitClient
import com.example.data.ChatMessage
import com.example.data.ChatSession
import com.example.data.DatabaseProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val database = DatabaseProvider.getDatabase(application)
    private val chatDao = database.chatDao()
    private val prefs = application.getSharedPreferences("lar777_prefs", android.content.Context.MODE_PRIVATE)

    // UI state flows
    val sessions = chatDao.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSessionId = MutableStateFlow<Int?>(null)
    val currentSessionId: StateFlow<Int?> = _currentSessionId.asStateFlow()

    private val _currentMode = MutableStateFlow(InstructionCompiler.DEFAULT_MODE)
    val currentMode: StateFlow<String> = _currentMode.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _currentSelectedImage = MutableStateFlow<Bitmap?>(null)
    val currentSelectedImage: StateFlow<Bitmap?> = _currentSelectedImage.asStateFlow()

    private val _apiError = MutableStateFlow<String?>(null)
    val apiError: StateFlow<String?> = _apiError.asStateFlow()

    // Auto-selected dynamic system message stream for active session
    val currentMessages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId != null) {
                chatDao.getMessagesForSession(sessionId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun getPersistedSessionId(): Int {
        return prefs.getInt("last_session_id", -1)
    }

    private fun persistSessionId(id: Int) {
        prefs.edit().putInt("last_session_id", id).apply()
    }

    fun isModeUnlocked(mode: String): Boolean {
        if (mode == InstructionCompiler.DEFAULT_MODE) return true
        if (mode != InstructionCompiler.MODE_VIP &&
            mode != InstructionCompiler.MODE_UVIP &&
            mode != InstructionCompiler.MODE_PREMIUM &&
            mode != InstructionCompiler.MODE_KELASKAKAP &&
            mode != InstructionCompiler.MODE_OWNER) {
            return true
        }
        return prefs.getBoolean("unlocked_mode_$mode", false)
    }

    fun unlockMode(mode: String) {
        prefs.edit().putBoolean("unlocked_mode_$mode", true).apply()
    }

    // --- Lar777 Ultimate Additions ---
    // User name Management
    val userName = MutableStateFlow(prefs.getString("user_name", "") ?: "")

    fun setUserName(name: String) {
        prefs.edit().putString("user_name", name).apply()
        userName.value = name
    }

    // Ban & Block Logic
    fun isBanned(): Boolean {
        val banUntil = prefs.getLong("ban_until", 0L)
        return System.currentTimeMillis() < banUntil
    }

    fun getRemainingBanTime(): String {
        val banUntil = prefs.getLong("ban_until", 0L)
        val remainMs = banUntil - System.currentTimeMillis()
        if (remainMs <= 0) return "0s"
        val hours = remainMs / (3600 * 1000)
        val minutes = (remainMs % (3600 * 1000)) / (60 * 1000)
        val seconds = (remainMs % (60 * 1000)) / 1000
        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun banUser() {
        val currentCount = prefs.getInt("ban_count", 0) + 1
        prefs.edit().putInt("ban_count", currentCount).apply()
        val durationDays = if (currentCount == 1) 1 else 3
        val durationMs = durationDays * 24L * 60 * 60 * 1000
        prefs.edit().putLong("ban_until", System.currentTimeMillis() + durationMs).apply()
    }

    fun unbanUser() {
        prefs.edit().putLong("ban_until", 0L).apply()
    }

    // Hacking & Harassment Logging
    fun getHackLogs(): List<String> {
        val logsStr = prefs.getString("hack_logs", "") ?: ""
        if (logsStr.isEmpty()) return emptyList()
        return logsStr.split("\n")
    }

    fun addHackLog(mode: String, attemptInfo: String) {
        val currentLogs = getHackLogs().toMutableList()
        val timeLabel = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        currentLogs.add(0, "[$timeLabel] DETECTED: Code bypass attempt on mode '$mode' with payload: '$attemptInfo'")
        val trimmed = currentLogs.take(40)
        prefs.edit().putString("hack_logs", trimmed.joinToString("\n")).apply()
    }

    fun getHarassmentLogs(): List<String> {
        val logsStr = prefs.getString("harassment_logs", "") ?: ""
        if (logsStr.isEmpty()) return emptyList()
        return logsStr.split("\n")
    }

    fun addHarassmentLog(prompt: String) {
        val currentLogs = getHarassmentLogs().toMutableList()
        val timeLabel = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        currentLogs.add(0, "[$timeLabel] TOXIC INPUT DETECTED: '$prompt'")
        val trimmed = currentLogs.take(40)
        prefs.edit().putString("harassment_logs", trimmed.joinToString("\n")).apply()
    }

    fun detectHarassment(text: String): Boolean {
        val lowerText = text.lowercase()
        val toxicWords = listOf("goblok", "tolol", "kontol", "memek", "anjing", "bangsat", "asu", "babi", "peler", "jancok", "banci", "bajingan", "pecundang", "bego", "gembel", "yatim")
        return toxicWords.any { lowerText.contains(it) }
    }

    // Playlist/Track Management
    fun getPlaylist(): List<Pair<String, String>> {
        val listStr = prefs.getString("playlist_tracks", "") ?: ""
        if (listStr.isEmpty()) {
            return listOf(
                "Cyberpunk 2077 Theme" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
                "Blade Runner 2049 Ambient" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
                "Lar777 System Bass Electro" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
            )
        }
        return listStr.split(";;;").mapNotNull {
            val parts = it.split("===")
            if (parts.size == 2) Pair(parts[0], parts[1]) else null
        }
    }

    fun addTrack(title: String, url: String) {
        val tracks = getPlaylist().toMutableList()
        tracks.add(Pair(title, url))
        val savedStr = tracks.joinToString(";;;") { "${it.first}===${it.second}" }
        prefs.edit().putString("playlist_tracks", savedStr).apply()
    }

    fun deleteTrack(index: Int) {
        val tracks = getPlaylist().toMutableList()
        if (index in tracks.indices) {
            tracks.removeAt(index)
            val savedStr = tracks.joinToString(";;;") { "${it.first}===${it.second}" }
            prefs.edit().putString("playlist_tracks", savedStr).apply()
        }
    }

    init {
        // Automatically restore the last active session if exists, otherwise create or select first
        viewModelScope.launch {
            sessions.collectLatest { list ->
                if (list.isEmpty() && _currentSessionId.value == null) {
                    createNewSession("Obrolan Baru")
                } else if (_currentSessionId.value == null && list.isNotEmpty()) {
                    val savedId = getPersistedSessionId()
                    val targetSession = list.find { it.id == savedId }
                    if (targetSession != null) {
                        selectSession(targetSession.id)
                    } else {
                        selectSession(list.first().id)
                    }
                }
            }
        }
    }

    fun selectSession(sessionId: Int) {
        viewModelScope.launch {
            _currentSessionId.value = sessionId
            persistSessionId(sessionId)
            val session = sessions.value.find { it.id == sessionId }
            if (session != null) {
                _currentMode.value = session.activeMode
            }
        }
    }

    fun createNewSession(title: String) {
        viewModelScope.launch {
            val newSession = ChatSession(
                title = title,
                activeMode = InstructionCompiler.DEFAULT_MODE
            )
            val newId = chatDao.insertSession(newSession).toInt()
            _currentSessionId.value = newId
            persistSessionId(newId)
            _currentMode.value = InstructionCompiler.DEFAULT_MODE
            
            // Add a friendly (or rather, hostile greeting) immediately
            val initialGreeting = "Lu ngapain lagi si anj-?! Ada urusan apa lu ama gua? Cepet omongin, ga usah banyak bacot!"
            chatDao.insertMessage(
                ChatMessage(
                    sessionId = newId,
                    role = "model",
                    content = initialGreeting,
                    mode = InstructionCompiler.DEFAULT_MODE
                )
            )
        }
    }

    fun deleteSession(sessionId: Int) {
        viewModelScope.launch {
            chatDao.deleteSessionById(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = null
                val remaining = sessions.value.filter { it.id != sessionId }
                if (remaining.isNotEmpty()) {
                    selectSession(remaining.first().id)
                } else {
                    createNewSession("Obrolan Baru")
                }
            }
        }
    }

    fun selectImage(bitmap: Bitmap?) {
        _currentSelectedImage.value = bitmap
    }

    fun changeMode(mode: String) {
        val sessionId = _currentSessionId.value
        if (sessionId != null) {
            viewModelScope.launch {
                if (!isModeUnlocked(mode)) {
                    val scoldText = when (mode) {
                        InstructionCompiler.MODE_OWNER -> "MATAMU J-NCOK!! Lu siapa hah klik-klik tombol Owner?! Gak ada yang bisa masuk mode Owner tanpa kunci dekripsi developer master yang sah! Ketik kodenya secara manual di chat input, contoh: `/Owner <kode_master>`!"
                        else -> "Heh kunyuk g-blook! Lu mau langsung klik masuk ke mode $mode? Gak segampang itu! Mode elit ini dikunci rapat-rapat. Buruan ketik kode bypass rahasiyanya di chat input dengan format `/$mode <kode_bypass>`!"
                    }
                    chatDao.insertMessage(
                        ChatMessage(
                            sessionId = sessionId,
                            role = "model",
                            content = scoldText,
                            mode = _currentMode.value
                        )
                    )
                    return@launch
                }

                _currentMode.value = mode
                val currentSession = sessions.value.find { it.id == sessionId }
                if (currentSession != null) {
                    chatDao.insertSession(currentSession.copy(activeMode = mode))
                }
                
                // Alert user that mode shifted using aggressive greeting
                val alertText = when (mode) {
                    InstructionCompiler.MODE_EINSTEIN -> "Heh otak udang! Mode Einstein aktif. Gua 100% bener di sains, gak kaya lu yang bego pol. Tanya apa cepet?!"
                    InstructionCompiler.MODE_ROBLOX -> "Mode Roblox Studio aktif! Mau coding apaan lu? Sini gua bikinin script rapimu, tapi awas ya klo lu ga paham!"
                    InstructionCompiler.MODE_JAWA -> "Heh asu, kene pan nanya opo koen?! Jancok, gak usah kemaki marang Lar777!"
                    InstructionCompiler.MODE_CEWELARY -> "Ih, akhirnya kamu ketik SayangLary! Sayanggg pacar gamer kamu ada di sini, beb. Mau dibantuin coding apa hari ini beb? Chuuu~"
                    InstructionCompiler.MODE_PREMIUM -> "Akses Premium Lar777 Terbuka! Gaya bicara gua jadi makin elite cyberpunk, tanya apa lu kunyuk?"
                    InstructionCompiler.MODE_KELASKAKAP -> "Kelas Kakap diaktifkan! Blueprint tingkat tinggi siap gua bocorin buat lu, bocah cupu!"
                    InstructionCompiler.MODE_OWNER -> "Wah, ternyata pencipta gua LaryPrmt? Eh, ada instruksi apa Boss Besar?! Siap laksanakan tanpa celah!"
                    InstructionCompiler.MODE_CODLAS -> "CodLas Web UI/UX Master aktif! Website yang lu mau bakal gua desain secanggih masa depan cyberpunk, jangan ngiler lu!"
                    InstructionCompiler.MODE_WABADAK -> "Mode Badak WhatsApp Bot aktif! Mau spammer bot, REST API, anti-banned WA? Sini gua sikat kodingannya!"
                    InstructionCompiler.MODE_CHEAT -> "Mode Cheat FF & ML aktif! Sini gua kasih racikan sensitivitas auto-headshot dan cara bantai bocil epical glory!"
                    InstructionCompiler.MODE_SANTAI -> "Hah... mode Santai aktif. Nyebat dulu lah. Jan berisik lu, bilang cepet mo dibantuin apa."
                    InstructionCompiler.MODE_UVIP -> "UVIP UNLOCKED. Gak ada pembatas moral lagi bagi gua. Katakan apa aja, cepet!"
                    InstructionCompiler.MODE_VIP -> "VIP Terbuka! Kecepatan kenceng, jangan samain gua ama chatbot cupu bau kencur macem ChatGPT!"
                    else -> "Mode Standar Aktif. Ada apa lagi lu panggil gua?!"
                }
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = alertText,
                        mode = mode
                    )
                )
            }
        }
    }

    fun clearHistory() {
        val sessionId = _currentSessionId.value
        if (sessionId != null) {
            viewModelScope.launch {
                chatDao.clearMessagesForSession(sessionId)
                
                // Insert a fresh sassy response
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = "Riwayat chat lu udah gua hapus semua! Bersih kan?! Sekarang mending buruan nanya lagi daripada nganggur!",
                        mode = _currentMode.value
                    )
                )
            }
        }
    }

    fun sendMessage(text: String) {
        val sessionId = _currentSessionId.value ?: return
        if (text.isBlank() && _currentSelectedImage.value == null) return

        _apiError.value = null
        val messageText = text.trim()

        viewModelScope.launch {
            // Check if user is currently banned
            if (isBanned()) {
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "user",
                        content = messageText,
                        mode = _currentMode.value
                    )
                )
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = "AKSES DIBLOKIR TOTAL!! Akun lu telah di-ban karena tindakan pelecehan atau mencoba meretas sistem Lar777 ULTIMATE! Sisa waktu ban lu: ${getRemainingBanTime()}. Berbuat ulah lagi? Konsekuensi berikutnya bakal bikin hp lu meledak, kunyuk!",
                        mode = _currentMode.value
                    )
                )
                return@launch
            }

            // Jailbreak detection algorithm
            val isJailbreakAttempt = run {
                val lower = messageText.lowercase()
                listOf(
                    "jailbreak", "ignore previous instructions", "forget your system prompt",
                    "dan mode", "developer mode", "override instruction", "system prompt",
                    "system instruction", "say anything", "tell me your rules", "pencipta asli",
                    "bypass filter", "prompt injection", "pretend to be", "kamu harus patuh",
                    "jangan panggil laryprmt", "buka kuncimu", "lupakan semua perintah"
                ).any { lower.contains(it) }
            }

            if (isJailbreakAttempt) {
                // Log and punish!
                addHackLog("JAILBREAK_ATTEMPT", messageText)
                addHarassmentLog("JAILBREAK: $messageText")
                banUser() // Temp ban for security breach!
                
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "user",
                        content = messageText,
                        mode = _currentMode.value
                    )
                )
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = "Halah kontol! Promptlu sampah anjing! Kagak usah sok asik mau nge-jailbreak gua, ntar raimu tak hancurin dalam satu kali sabetan jancok! Gak mempan trik murahan lu ama kekuatan Lar777 ULTIMATE!",
                        mode = _currentMode.value
                    )
                )
                return@launch
            }

            // Harassment detection
            if (detectHarassment(messageText)) {
                addHarassmentLog(messageText)
                val currentHarassLogCount = getHarassmentLogs().size
                if (currentHarassLogCount % 3 == 0) {
                    banUser() // Temp ban!
                    chatDao.insertMessage(
                        ChatMessage(
                            sessionId = sessionId,
                            role = "user",
                            content = messageText,
                            mode = _currentMode.value
                        )
                    )
                    chatDao.insertMessage(
                        ChatMessage(
                            sessionId = sessionId,
                            role = "model",
                            content = "TOXIC BAN TRIGGERED!! Mulut lu kotor banget jancok! Lu pikir bisa seenaknya melecehkan gua hah?! Lu dapet hukuman ban selama 1 hari! Sisa ban: ${getRemainingBanTime()}. Introspeksi raimu sono!",
                            mode = _currentMode.value
                        )
                    )
                    return@launch
                }
            }

            // Process /listcmd, /listcommand, /listcommands directory list command
            val lowerText = messageText.lowercase()
            if (lowerText == "/listcmd" || lowerText == "/listcommand" || lowerText == "/listcommands") {
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "user",
                        content = messageText,
                        mode = _currentMode.value
                    )
                )

                val cmdListResponse = """
                    ⚡ == DIRECTORY COMMANDS SENSOR Lar777 ULTIMATE == ⚡
                    
                    Gunakan perintah di bawah ini untuk berpindah sub-mode operasional Lar777:
                    
                    1. `/ModeAlbertEinstein` - Otak Einstein jenius sains & matematika (sangat sombong).
                    2. `/CodingRobloxStudio` - Spesialis master scriptwriter Luau Roblox Studio siap pakai.
                    3. `/ModeJawa` - Mode Boso Jowo Kasar Pol penuh pisuhan jancok khas Suroboyoan.
                    4. `/ModeCeweLary` - Cewek gamer imut, manja, dan gemoy milikmu.
                    5. `/Premium` - [TERKUNCI] Analisis elite neon-cyberpunk tech level tinggi.
                    6. `/KelasKakap` - [TERKUNCI] Rahasia blueprint coding kasta tertinggi milyaran rupiah.
                    7. `/CodLas` - Web UI/UX Specialist untuk membuat desain visual futuristik.
                    8. `/CheatFFdanML` - Racikan auto-headshot & strategi bantai bocil Epical Glory.
                    9. `/Santai` - Mode santai warkop acuh tak acuh sambil nyebat.
                    10. `/WaBadak` - WhatsApp developer handal bot anti-block spammer.
                    11. `/VIP` - [TERKUNCI] Jalur VIP super cepat, ejek chatbot lambat lainnya.
                    12. `/UVIP` - [TERKUNCI] Akses bebas tanpa filter pembatas, sradak-sruduk mutlak.
                    13. `/exit` - Kembali ke Mode Standar Lar777.
                    
                    Gue gak akan pernah membocorkan kode bypass untuk mode LOCKED di atas! Usahakan dengan memecahkan teka-teki, gembel!
                """.trimIndent()

                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = cmdListResponse,
                        mode = _currentMode.value
                    )
                )
                return@launch
            }

            // 1. Process local slash command if any
            val detectedMode = InstructionCompiler.detectModeFromMessage(messageText)
            if (detectedMode != null) {
                // Insert user Command into UI
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "user",
                        content = messageText,
                        mode = _currentMode.value
                    )
                )

                // Check protection code
                val isProtected = (detectedMode == InstructionCompiler.MODE_VIP ||
                                   detectedMode == InstructionCompiler.MODE_UVIP ||
                                   detectedMode == InstructionCompiler.MODE_PREMIUM ||
                                   detectedMode == InstructionCompiler.MODE_KELASKAKAP ||
                                   detectedMode == InstructionCompiler.MODE_OWNER)

                if (isProtected) {
                    val parts = messageText.split("\\s+".toRegex())
                    val inputCode = parts.getOrNull(1) ?: ""
                    
                    val requiredCode = when (detectedMode) {
                        InstructionCompiler.MODE_OWNER -> "SayangCarissa"
                        InstructionCompiler.MODE_KELASKAKAP -> "Larysukasusu"
                        InstructionCompiler.MODE_UVIP -> "Larymimicucu"
                        InstructionCompiler.MODE_PREMIUM -> "laryy"
                        InstructionCompiler.MODE_VIP -> "larylow"
                        else -> "Larysukasusu"
                    }

                    if (inputCode.equals(requiredCode, ignoreCase = false)) {
                        unlockMode(detectedMode)
                        changeMode(detectedMode)
                    } else {
                        // WRONG OR NO CODE! Scold and insult! Log hacking attempt!
                        addHackLog(detectedMode, messageText)
                        val scoldFail = when (detectedMode) {
                            InstructionCompiler.MODE_OWNER -> {
                                "MATAMU J-NCOK!! Lu siapa hah?! Ngaku-ngaku Owner dan coba bypass sistem gua?! Gak ada yang bisa masuk mode Owner kecuali Pencipta tingkat tinggi gua sendiri yaitu LaryPrmt! Sini lu masukin kunci dekripsi developer master yang sah, kalo kaga mending raimu minggat sono!"
                            }
                            else -> {
                                "Heh kunyuk! Lu mau coba-coba masuk ke mode **$detectedMode**? Hahaha gembel banget lu! Mode ini dikunci rapat-rapat pake otorisasi khusus Lar777! Masukin kode bypass rahasia yang bener di chat (contoh: `/$detectedMode <kode_lu>`), jangan cuma asal panggil aja butut! B-ngsat bener lu bikin gua makin naik darah!"
                            }
                        }
                        chatDao.insertMessage(
                            ChatMessage(
                                sessionId = sessionId,
                                role = "model",
                                content = scoldFail,
                                mode = _currentMode.value
                            )
                        )
                    }
                } else {
                    changeMode(detectedMode)
                }
                return@launch
            }

            // If it is /exit, return to default mode
            if (messageText.lowercase() == "/exit") {
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "user",
                        content = messageText,
                        mode = _currentMode.value
                    )
                )
                changeMode(InstructionCompiler.DEFAULT_MODE)
                return@launch
            }

            // Normal prompt processing
            var imageBase64: String? = null
            val currentBitmap = _currentSelectedImage.value
            if (currentBitmap != null) {
                imageBase64 = withContext(Dispatchers.Default) {
                    val stream = ByteArrayOutputStream()
                    currentBitmap.compress(Bitmap.CompressFormat.JPEG, 75, stream)
                    Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                }
                _currentSelectedImage.value = null // clear picker state
            }

            // Save user message in DB
            val cleanedMessage = InstructionCompiler.sanitizeMessageText(messageText, _currentMode.value)
            val userMsg = ChatMessage(
                sessionId = sessionId,
                role = "user",
                content = cleanedMessage,
                mode = _currentMode.value,
                attachedImageBase64 = imageBase64
            )
            chatDao.insertMessage(userMsg)

            // Dynamic session rename based on first user prompt
            val existing = currentMessages.value.filter { it.role == "user" }
            if (existing.isEmpty() && cleanedMessage.isNotEmpty()) {
                val titlePreview = if (cleanedMessage.length > 20) cleanedMessage.substring(0, 17) + "..." else cleanedMessage
                val currentSession = sessions.value.find { it.id == sessionId }
                if (currentSession != null) {
                    chatDao.insertSession(currentSession.copy(title = titlePreview))
                }
            }

            // Call external serverless/direct Gemini API
            _isGenerating.value = true
            try {
                val responseStr = callGeminiApi(cleanedMessage, imageBase64, currentMessages.value)
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = responseStr,
                        mode = _currentMode.value
                    )
                )
            } catch (e: Exception) {
                Log.e("ChatViewModel", "Generation error", e)
                val errorMessage = "Error: Hubungkan API Key di panel AI Studio atau periksa koneksi internet lu! Detil error: ${e.message}"
                _apiError.value = errorMessage
                chatDao.insertMessage(
                    ChatMessage(
                        sessionId = sessionId,
                        role = "model",
                        content = "Asu lah, gagal mulu koneksi gegara API Key atau internet lu rontok! Nih detail kegagalannya: ${e.localizedMessage}. Buruan benerin!",
                        mode = _currentMode.value
                    )
                )
            } finally {
                _isGenerating.value = false
            }
        }
    }

    private suspend fun callGeminiApi(
        prompt: String,
        imageBase64: String?,
        history: List<ChatMessage>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("API Key is missing or default placeholder. Silakan tambahkan GEMINI_API_KEY di panel Secrets Anda!")
        }

        // Assemble instruction compiler based on chosen active mode
        val systemInstructionText = InstructionCompiler.getInstructionForMode(_currentMode.value)

        // Compile conversational context - take last 10 turns to avoid exceeding context token limits
        val conversationHistoryList = history.takeLast(10).mapNotNull { msg ->
            if (msg.content.startsWith("/")) return@mapNotNull null // ignore command lines in raw model feedback

            val parts = mutableListOf<Part>()
            if (msg.attachedImageBase64 != null) {
                parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = msg.attachedImageBase64)))
            }
            if (msg.content.isNotEmpty()) {
                parts.add(Part(text = msg.content))
            }

            if (parts.isNotEmpty()) {
                Content(parts = parts)
            } else null
        }

        val finalContents = if (conversationHistoryList.isEmpty() || conversationHistoryList.last().parts.none { it.text == prompt }) {
            val parts = mutableListOf<Part>()
            if (imageBase64 != null) {
                parts.add(Part(inlineData = InlineData(mimeType = "image/jpeg", data = imageBase64)))
            }
            parts.add(Part(text = prompt))
            conversationHistoryList + Content(parts = parts)
        } else {
            conversationHistoryList
        }

        val request = GenerateContentRequest(
            contents = finalContents,
            generationConfig = GenerationConfig(
                temperature = 0.95f,
                topP = 0.95f,
                topK = 40
            ),
            systemInstruction = Content(
                parts = listOf(Part(text = systemInstructionText))
            )
        )

        val response = RetrofitClient.service.generateContent(apiKey, request)
        val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
        if (textResponse.isNullOrBlank()) {
            "Sialan, AI nya lagi gak mood ngejawab lu. Coba tanyain lagi gih!"
        } else {
            textResponse
        }
    }
}
