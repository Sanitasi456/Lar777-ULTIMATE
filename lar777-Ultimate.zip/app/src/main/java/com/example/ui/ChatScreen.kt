package com.example.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.InstructionCompiler
import com.example.data.ChatMessage
import com.example.data.ChatSession
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.io.InputStream
import kotlin.random.Random

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val sessions by viewModel.sessions.collectAsState()
    val messages by viewModel.currentMessages.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val currentSelectedImage by viewModel.currentSelectedImage.collectAsState()
    val apiError by viewModel.apiError.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    // --- State variables for loading progress, active sub-panels, and custom name prompts ---
    var isAppLoading by remember { mutableStateOf(true) }
    var loadingProgress by remember { mutableFloatStateOf(0.0f) }
    val savedUserName by viewModel.userName.collectAsState()
    var activeTabState by remember { mutableStateOf("CHAT") }

    // Simulating loading animation progress manually on launch
    LaunchedEffect(Unit) {
        val totalSteps = 20
        for (i in 1..totalSteps) {
            kotlinx.coroutines.delay(100)
            loadingProgress = i.toFloat() / totalSteps
        }
        isAppLoading = false
    }

    val isBanned = viewModel.isBanned()
    if (isBanned) {
        BannedTerminalView(viewModel = viewModel)
        return
    }

    if (isAppLoading) {
        CyberLoadingView(progress = loadingProgress)
        return
    }

    if (savedUserName.isBlank()) {
        UsernameRegistrationView(onSave = { name -> viewModel.setUserName(name) })
        return
    }

    // Media Picker Launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                viewModel.selectImage(bitmap)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp),
                drawerTonalElevation = 8.dp,
                drawerContainerColor = CyberSurface
            ) {
                Spacer(modifier = Modifier.height(48.dp))
                
                // Sidebar Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .background(
                            Brush.linearGradient(listOf(NeonBlue, NeonPurple)),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "LAR777 CLIENT v6.0",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Created by LaryPrmt",
                            color = Color.Black.copy(alpha = 0.8f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action buttons inside Sidebar
                Button(
                    onClick = {
                        viewModel.createNewSession("Obrolan Baru")
                        coroutineScope.launch { drawerState.close() }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("new_chat_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = Color.Black)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "New Chat")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Session Baru", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Daftar Riwayat Sesi:",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 20.dp, bottom = 8.dp)
                )

                // List of past chat instances
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    items(sessions) { session ->
                        val isSelected = session.id == currentSessionId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonPurple.copy(alpha = 0.25f) else Color.Transparent)
                                .clickable {
                                    viewModel.selectSession(session.id)
                                    coroutineScope.launch { drawerState.close() }
                                }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Message,
                                contentDescription = "Chat Session",
                                tint = if (isSelected) NeonBlue else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = session.title,
                                color = if (isSelected) Color.White else TextPrimary,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.deleteSession(session.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Session",
                                    tint = AccentOrange.copy(alpha = 0.8f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        // Sophisticated Deep Dark Backdrop
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberBg)
        ) {

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "LAR777 • ULTIMATE CORE",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    color = NeonBlue,
                                    fontFamily = FontFamily.Monospace
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(if (isGenerating) AccentOrange else Color.Green)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isGenerating) "AI BERPIKIR..." else "STATUS: KONEKSI COLD-SYNC ONLINE",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isGenerating) AccentOrange else Color.Green,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = NeonBlue
                                )
                            }
                        },
                        actions = {
                            IconButton(onClick = { viewModel.clearHistory() }) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Clear Session",
                                    tint = AccentOrange
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = CyberBg.copy(alpha = 0.85f)
                        )
                    )
                }
            ) { paddingValues ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    // Left Column: Switched viewport
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            when (activeTabState) {
                                "CHAT" -> {
                                    Column(
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        // Current mode banner indicator
                                        ModeBanner(mode = currentMode, onExit = { viewModel.changeMode(InstructionCompiler.DEFAULT_MODE) })

                                        // Chat Messages List
                                        val listState = rememberLazyListState()
                                        LaunchedEffect(messages.size) {
                                            if (messages.isNotEmpty()) {
                                                listState.animateScrollToItem(messages.size - 1)
                                            }
                                        }

                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxWidth()
                                        ) {
                                            if (messages.isEmpty()) {
                                                EmptyStatePlaceholder { cmd -> viewModel.sendMessage(cmd) }
                                            } else {
                                                LazyColumn(
                                                    state = listState,
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .padding(horizontal = 12.dp)
                                                ) {
                                                    items(messages) { message ->
                                                        ChatMessageRow(message = message, viewModel = viewModel)
                                                    }
                                                    if (isGenerating) {
                                                        item {
                                                            TypingIndicatorRow()
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        // API Error notice banner
                                        if (apiError != null) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(AccentOrange.copy(alpha = 0.2f))
                                                    .border(1.dp, AccentOrange, RoundedCornerShape(4.dp))
                                                    .padding(8.dp)
                                            ) {
                                                Text(
                                                    text = apiError ?: "",
                                                    color = AccentOrange,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(6.dp)
                                                )
                                            }
                                        }

                                        // Input footer panel
                                        InputFooter(
                                            currentSelectedImage = currentSelectedImage,
                                            onPickImage = { imagePickerLauncher.launch("image/*") },
                                            onClearImage = { viewModel.selectImage(null) },
                                            onSendMessage = {
                                                viewModel.sendMessage(it)
                                                keyboardController?.hide()
                                            }
                                        )
                                    }
                                }
                                "SYSTEM" -> {
                                    SystemPanel(viewModel = viewModel)
                                }
                                "VAULT" -> {
                                    VaultPanel(viewModel = viewModel)
                                }
                            }
                        }

                        // High-tech lower status system navigation indicators persistently at the bottom!
                        BottomNavigationBar(
                            activeTab = activeTabState,
                            onTabChange = { activeTabState = it }
                        )
                    }

                    // Floating sidebar command triggers for larger screens (Foldables/Tablets integration)
                    BoxWithConstraints {
                        if (maxWidth > 650.dp) {
                            Column(
                                modifier = Modifier
                                    .width(180.dp)
                                    .fillMaxHeight()
                                    .background(CyberSurface.copy(alpha = 0.9f))
                                    .border(1.dp, NeonPurple.copy(alpha = 0.3f))
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "⚡ QUICK COMMANDS",
                                    color = NeonBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                                QuickCommandItem(title = "Einstein", cmd = "/ModeAlbertEinstein", active = currentMode == InstructionCompiler.MODE_EINSTEIN) { viewModel.changeMode(InstructionCompiler.MODE_EINSTEIN) }
                                QuickCommandItem(title = "Roblox", cmd = "/CodingRobloxStudio", active = currentMode == InstructionCompiler.MODE_ROBLOX) { viewModel.changeMode(InstructionCompiler.MODE_ROBLOX) }
                                QuickCommandItem(title = "Mode Jawa", cmd = "/ModeJawa", active = currentMode == InstructionCompiler.MODE_JAWA) { viewModel.changeMode(InstructionCompiler.MODE_JAWA) }
                                QuickCommandItem(title = "Cewe Lary", cmd = "/ModeCeweLary SayangLary", active = currentMode == InstructionCompiler.MODE_CEWELARY) { viewModel.changeMode(InstructionCompiler.MODE_CEWELARY) }
                                QuickCommandItem(title = "Premium", cmd = "/Premium", active = currentMode == InstructionCompiler.MODE_PREMIUM) { viewModel.changeMode(InstructionCompiler.MODE_PREMIUM) }
                                QuickCommandItem(title = "Kelas Kakap", cmd = "/KelasKakap", active = currentMode == InstructionCompiler.MODE_KELASKAKAP) { viewModel.changeMode(InstructionCompiler.MODE_KELASKAKAP) }
                                QuickCommandItem(title = "VIP", cmd = "/VIP", active = currentMode == InstructionCompiler.MODE_VIP) { viewModel.changeMode(InstructionCompiler.MODE_VIP) }
                                QuickCommandItem(title = "UVIP", cmd = "/UVIP", active = currentMode == InstructionCompiler.MODE_UVIP) { viewModel.changeMode(InstructionCompiler.MODE_UVIP) }
                                QuickCommandItem(title = "CodLas Web", cmd = "/CodLas", active = currentMode == InstructionCompiler.MODE_CODLAS) { viewModel.changeMode(InstructionCompiler.MODE_CODLAS) }
                                QuickCommandItem(title = "Cheat FF/ML", cmd = "/CheatFFdanML", active = currentMode == InstructionCompiler.MODE_CHEAT) { viewModel.changeMode(InstructionCompiler.MODE_CHEAT) }
                                QuickCommandItem(title = "Santai", cmd = "/Santai", active = currentMode == InstructionCompiler.MODE_SANTAI) { viewModel.changeMode(InstructionCompiler.MODE_SANTAI) }
                                QuickCommandItem(title = "WhatsApp", cmd = "/WaBadak", active = currentMode == InstructionCompiler.MODE_WABADAK) { viewModel.changeMode(InstructionCompiler.MODE_WABADAK) }
                                QuickCommandItem(title = "List Command", cmd = "/ListCommand", active = false) { viewModel.sendMessage("/ListCommand") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StarryNebulaBackground() {
    val infiniteTransition = rememberInfiniteTransition()
    val nebulaScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Background Radial Gradient for nebulas
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonPurple.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = Offset(width * 0.2f, height * 0.3f),
                radius = width * nebulaScale
            )
        )

        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonBlue.copy(alpha = 0.1f),
                    Color.Transparent
                ),
                center = Offset(width * 0.8f, height * 0.7f),
                radius = width * (2.0f - nebulaScale)
            )
        )

        // Draw 30 static starry points
        val random = Random(42) // Consistent seeding of particle coordinates
        for (i in 0..40) {
            val rx = random.nextFloat() * width
            val ry = random.nextFloat() * height
            val rRadius = random.nextFloat() * 2.5f + 0.5f
            val rAlpha = random.nextFloat() * 0.6f + 0.4f
            drawCircle(
                color = Color.White.copy(alpha = rAlpha),
                radius = rRadius,
                center = Offset(rx, ry)
            )
        }
    }
}

@Composable
fun ModeBanner(mode: String, onExit: () -> Unit) {
    if (mode == InstructionCompiler.DEFAULT_MODE) return

    val displayDetails = when (mode) {
        InstructionCompiler.MODE_EINSTEIN -> Pair("Albert Einstein", NeonBlue)
        InstructionCompiler.MODE_ROBLOX -> Pair("Roblox Luau Studio", NeonPurple)
        InstructionCompiler.MODE_JAWA -> Pair("Boso Jowo Kasar", AccentOrange)
        InstructionCompiler.MODE_CEWELARY -> Pair("Cewe Lary Pacar Gamer", Color(0xFFFF69B4))
        InstructionCompiler.MODE_PREMIUM -> Pair("Lar777 Premium Mode", NeonBlue)
        InstructionCompiler.MODE_KELASKAKAP -> Pair("Kelas Kakap Blueprint", NeonPurple)
        InstructionCompiler.MODE_OWNER -> Pair("Developer Owner mode", Color.Red)
        InstructionCompiler.MODE_CODLAS -> Pair("Web CodLas Pro", NeonBlue)
        InstructionCompiler.MODE_CHEAT -> Pair("Cheat ML & FF Mode", AccentOrange)
        InstructionCompiler.MODE_SANTAI -> Pair("Santai Nyebat Mode", Color.Gray)
        InstructionCompiler.MODE_WABADAK -> Pair("WhatsApp Badak Integration", Color.Green)
        else -> Pair(mode, NeonBlue)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(displayDetails.second.copy(alpha = 0.15f))
            .border(1.dp, displayDetails.second.copy(alpha = 0.4f))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Active Mode",
                tint = displayDetails.second,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "MODE AKTIF: ${displayDetails.first.uppercase()}",
                color = displayDetails.second,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
        IconButton(
            onClick = onExit,
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Exit Mode",
                tint = displayDetails.second,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmptyStatePlaceholder(onCommandSelect: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .background(NeonPurple.copy(alpha = 0.15f), CircleShape)
                .border(2.dp, NeonBlue, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Terminal,
                contentDescription = "Terminal core",
                tint = NeonBlue,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "KONEKSI INTELEKTUAL DINAMIS LAR777",
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Text(
            text = "AI paling toxic, kasar, dan paling canggih dibuat oleh LaryPrmt. Ketik pesan lu di bawah atau aktifkan salah satu mode command berikut untuk menantang asisten kejam ini:",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterHorizontally),
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Direct clickable instructions command list matrix
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            val commandList = listOf(
                "/ModeAlbertEinstein",
                "/CodingRobloxStudio",
                "/ModeJawa",
                "/ModeCeweLary SayangLary",
                "/Premium",
                "/KelasKakap",
                "/VIP",
                "/UVIP",
                "/CodLas",
                "/CheatFFdanML",
                "/Santai",
                "/WaBadak"
            )
            commandList.forEach { cmd ->
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .background(CyberSurface, RoundedCornerShape(6.dp))
                        .border(1.dp, NeonBlue.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .clickable { onCommandSelect(cmd) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = cmd,
                        color = NeonBlue,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ChatMessageRow(message: ChatMessage, viewModel: ChatViewModel) {
    val isUser = message.role == "user"
    val arrangement = if (isUser) Arrangement.End else Arrangement.Start
    val targetText = message.content

    // Interactive custom typewriter state
    var typedText by remember(message.id, targetText) { mutableStateOf(if (isUser) targetText else "") }

    LaunchedEffect(message.id, targetText) {
        if (!isUser) {
            val length = targetText.length
            if (length <= 0) {
                typedText = ""
            } else {
                // Adjust typing speed and step sizes dynamically so that the overall animation feels organic
                // and finishes in approximately 800ms - 1.2s regardless of the message size.
                val totalSteps = 40
                val stepDelay = 15L
                val charsPerStep = (length / totalSteps).coerceAtLeast(1)

                var currentLength = 0
                while (currentLength < length) {
                    currentLength += charsPerStep
                    if (currentLength >= length) {
                        typedText = targetText
                        break
                    }
                    typedText = targetText.substring(0, currentLength)
                    kotlinx.coroutines.delay(stepDelay)
                }
                typedText = targetText
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = arrangement
    ) {
        if (!isUser) {
            // Lar777 Cyber Avatar display
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(NeonPurple, Color(0xFF0F0055))))
                    .border(1.dp, NeonBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "L7",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            // Chat Bubble - Styled with Sophisticated Dark gradient blocks
            if (isUser) {
                Box(
                    modifier = Modifier
                        .background(UserChatBg, shape = RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp))
                        .border(1.dp, BorderMedium, shape = RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Column {
                        if (message.attachedImageBase64 != null) {
                            ImageAttachmentPreview(base64Str = message.attachedImageBase64)
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        Text(
                            text = typedText,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(listOf(BotChatBgStart, BotChatBgEnd)),
                            shape = RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp)
                        )
                        .border(
                            1.dp,
                            NeonPurple.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(16.dp, 16.dp, 16.dp, 0.dp)
                        )
                        .clickable { typedText = targetText } // Multi-touch interactive bypass
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Column {
                        if (message.attachedImageBase64 != null) {
                            ImageAttachmentPreview(base64Str = message.attachedImageBase64)
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        Text(
                            text = typedText,
                            color = NeonBlue,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.Medium
                        )
                        if (typedText.length < targetText.length) {
                            // Subtle futuristic low-opacity blinker dot to represent typing progress inside bubble
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(AccentOrange)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "typing digital stream...",
                                    color = TextSecondary.copy(alpha = 0.5f),
                                    fontSize = 9.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Subtitle state info
            val savedUserName by viewModel.userName.collectAsState()
            val userLabel = if (savedUserName.isNotBlank()) savedUserName else "LaryPrmt"
            val modeLabel = if (message.mode != "DEFAULT") " [${message.mode}]" else ""
            Text(
                text = "${if (isUser) userLabel else "Lar777 ULTIMATE"}$modeLabel",
                color = if (isUser) TextSecondary.copy(alpha = 0.6f) else NeonPurple.copy(alpha = 0.8f),
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp, end = 4.dp)
            )
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            // User Space Avatar display
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonBlue, Color(0xFF041E42))))
                    .border(1.dp, NeonBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "User Avatar",
                    tint = NeonBlue,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun ImageAttachmentPreview(base64Str: String) {
    val bitmap = remember(base64Str) {
        try {
            val byteArr = Base64.decode(base64Str, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(byteArr, 0, byteArr.size)
        } catch (e: Exception) {
            null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Attached visual payload",
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 180.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, NeonBlue.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun TypingIndicatorRow() {
    val infiniteTransition = rememberInfiniteTransition()
    val floatBy by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(NeonPurple, Color(0xFF0F0055))))
                .border(1.dp, NeonBlue, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "L7",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(listOf(BotChatBgStart, BotChatBgEnd)),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(1.dp, NeonPurple.copy(alpha = 0.35f), shape = RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Mengejek user",
                    color = NeonBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .offset(y = floatBy.dp)
                        .size(4.dp)
                        .background(AccentOrange, CircleShape)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Box(
                    modifier = Modifier
                        .offset(y = (-floatBy).dp)
                        .size(4.dp)
                        .background(AccentOrange, CircleShape)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Box(
                    modifier = Modifier
                        .offset(y = floatBy.dp)
                        .size(4.dp)
                        .background(AccentOrange, CircleShape)
                )
            }
        }
    }
}

@Composable
fun InputFooter(
    currentSelectedImage: Bitmap?,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    var textState by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBg.copy(alpha = 0.95f))
            .border(1.dp, BorderDark)
            .padding(12.dp)
    ) {
        // Active selected image payload display block
        if (currentSelectedImage != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .background(CyberSurface, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    bitmap = currentSelectedImage.asImageBitmap(),
                    contentDescription = "Selected Picture",
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(6.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Gambar Siap Diupload",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onClearImage) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear Picture Choice",
                        tint = AccentOrange
                    )
                }
            }
        }

        // Horizontal scroll stream of direct command chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val footerChips = listOf(
                "/ModeJawa",
                "/CodLas",
                "/Premium",
                "/VIP",
                "/UVIP",
                "/KelasKakap",
                "/ModeCeweLary",
                "/ModeAlbertEinstein",
                "/CodingRobloxStudio",
                "/CheatFFdanML",
                "/Santai",
                "/WaBadak",
                "/listcmd"
            )
            items(footerChips) { chip ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (chip == "/listcmd") NeonBlue.copy(alpha = 0.12f) else CyberSurface
                        )
                        .border(
                            1.dp,
                            if (chip == "/listcmd") NeonBlue.copy(alpha = 0.4f) else BorderMedium,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            textState = if (chip == "/listcmd") chip else "$chip "
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = chip,
                        color = if (chip == "/listcmd") NeonBlue else Color.White.copy(alpha = 0.85f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Prompt Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPickImage,
                modifier = Modifier
                    .size(44.dp)
                    .background(CyberSurface, CircleShape)
                    .border(1.dp, BorderMedium, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.AttachFile,
                    contentDescription = "Attach File Image",
                    tint = NeonBlue
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            TextField(
                value = textState,
                onValueChange = { textState = it },
                placeholder = {
                    Text(
                        text = "Ketik perintah lu...",
                        color = TextSecondary.copy(alpha = 0.5f),
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("prompt_field"),
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberBg,
                    unfocusedContainerColor = CyberBg,
                    focusedIndicatorColor = NeonPurple.copy(alpha = 0.4f),
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(24.dp),
                maxLines = 4
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (textState.isNotBlank() || currentSelectedImage != null) {
                        onSendMessage(textState)
                        textState = ""
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .background(Brush.linearGradient(listOf(NeonPurple, NeonBlue)), CircleShape)
                    .testTag("send_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send Payload",
                    tint = Color.Black
                )
            }
        }
    }
}

@Composable
fun BottomNavigationBar(
    activeTab: String,
    onTabChange: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBg)
            .border(1.dp, BorderDark)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clickable { onTabChange("CHAT") }
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (activeTab == "CHAT") NeonBlue else Color.Transparent)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "CHAT",
                color = if (activeTab == "CHAT") NeonBlue else TextSecondary.copy(alpha = 0.4f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clickable { onTabChange("VAULT") }
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (activeTab == "VAULT") Color.Red else Color.Transparent)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "VAULT",
                color = if (activeTab == "VAULT") Color.Red else TextSecondary.copy(alpha = 0.4f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clickable { onTabChange("SYSTEM") }
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (activeTab == "SYSTEM") NeonPurple else Color.Transparent)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "SYSTEM",
                color = if (activeTab == "SYSTEM") NeonPurple else TextSecondary.copy(alpha = 0.4f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
fun QuickCommandItem(
    title: String,
    cmd: String,
    active: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (active) NeonBlue else Color.Transparent
    val backgroundFill = if (active) NeonPurple.copy(alpha = 0.25f) else CyberSurface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundFill)
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Text(
            text = title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
        Text(
            text = cmd,
            color = if (active) NeonBlue else TextSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ==================== LAR777 ULTIMATE CYBERVIEWS ====================

@Composable
fun CyberLoadingView(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg),
        contentAlignment = Alignment.Center
    ) {
        StarryNebulaBackground()
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(NeonPurple.copy(alpha = 0.4f), Color.Transparent)))
                    .border(1.5.dp, NeonBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "L7",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 32.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "LAR777 ULTIMATE SYSTEM CORE",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "STATUS: INITIALIZING DECRYPTION STREAM...",
                color = NeonBlue,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(CyberSurface)
                    .border(0.5.dp, NeonBlue.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxHeight()
                        .background(Brush.linearGradient(listOf(NeonBlue, NeonPurple)))
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "${(progress * 100).toInt()}% LOADED",
                color = NeonPurple,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun UsernameRegistrationView(onSave: (String) -> Unit) {
    var nameInput by remember { mutableStateOf("") }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBg),
        contentAlignment = Alignment.Center
    ) {
        StarryNebulaBackground()
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(16.dp))
                .background(CyberSurface.copy(alpha = 0.95f))
                .border(1.5.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = NeonBlue,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "IDENTITY AUTHENTICATION",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Masukkan nama bebas kamu untuk koneksi sistem Lar777 ULTIMATE",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            TextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                placeholder = { Text("Nama pengguna...", color = TextSecondary.copy(alpha = 0.5f)) },
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = CyberBg,
                    unfocusedContainerColor = CyberBg,
                    focusedIndicatorColor = NeonBlue,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = {
                    if (nameInput.isNotBlank()) {
                        onSave(nameInput.trim())
                    }
                },
                enabled = nameInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonBlue,
                    contentColor = Color.Black,
                    disabledContainerColor = CyberBg
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ESTABLISH CONNECTION", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun BannedTerminalView(viewModel: ChatViewModel) {
    var timerDisplay by remember { mutableStateOf(viewModel.getRemainingBanTime()) }
    var secretTapCount by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            timerDisplay = viewModel.getRemainingBanTime()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF150000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .border(2.dp, Color.Red, RoundedCornerShape(12.dp))
                .background(Color.Black)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = "Banned",
                tint = Color.Red,
                modifier = Modifier
                    .size(64.dp)
                    .clickable {
                        secretTapCount++
                        if (secretTapCount >= 5) {
                            viewModel.unbanUser()
                        }
                    }
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "⚡ ACCESS DENIED • SYSTEM BANNED ⚡",
                color = Color.Red,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Hp lu rongsokan atau kelakuan lu yang sampah?! Cobain bypass code hacking, cyber jailbreak, atau abusive spamming, akun lu akhirnya di-bricked paksa oleh Lar777!",
                color = Color.White,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .background(Color.Red.copy(alpha = 0.15f))
                    .border(1.dp, Color.Red, RoundedCornerShape(4.dp))
                    .padding(16.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "SISA WAKTU STATUS SHUTDOWN:",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = timerDisplay,
                        color = Color.Red,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Peringatan: Coba-coba bypass lagi, dapet sanksi permanent ban dari developer LaryPrmt!",
                color = Color.LightGray,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
            )
        }
    }
}

@Composable
fun SystemPanel(viewModel: ChatViewModel) {
    var songName by remember { mutableStateOf("") }
    var songUrl by remember { mutableStateOf("") }
    var activeStreamingTrack by remember { mutableStateOf<String?>(null) }
    var activeStreamingIndex by remember { mutableStateOf<Int?>(null) }

    var converterUrl by remember { mutableStateOf("") }
    var isConvertingState by remember { mutableStateOf(false) }
    var conversionProgress by remember { mutableFloatStateOf(0f) }
    val conversionLogs = remember { mutableStateListOf<String>() }
    val convertedFiles = remember { mutableStateListOf<Pair<String, String>>() }

    val playlist = remember { mutableStateOf(viewModel.getPlaylist()) }

    LaunchedEffect(isConvertingState) {
        if (isConvertingState) {
            conversionLogs.clear()
            conversionLogs.add("⌛ CONNECTION INITIALIZED...")
            kotlinx.coroutines.delay(400)
            conversionLogs.add("🔗 EXTRACTING AUDIO/VIDEO DIRECT STREAM...")
            conversionProgress = 0.25f
            kotlinx.coroutines.delay(400)
            conversionLogs.add("🛠️ DECOY CYBER LINK PARSING...")
            conversionProgress = 0.60f
            kotlinx.coroutines.delay(500)
            conversionLogs.add("⚡ RENDERING TRANSLATED STREAM CHANNELS...")
            conversionProgress = 0.85f
            kotlinx.coroutines.delay(600)
            conversionLogs.add("✅ SOCIAL MEDIA DOWNLOAD COMPLETED!")
            conversionProgress = 1.0f
            
            val domain = try {
                val host = java.net.URI(converterUrl).host ?: "social"
                host.replace("www.", "").split(".")[0]
            } catch (e: Exception) {
                "media_source"
            }
            convertedFiles.add(0, Pair("Converted_${domain}_stream_${Random.nextInt(100, 999)}", "Format (.mp4)"))
            isConvertingState = false
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "🛠️ LAR777 UTILITIES INTERFACE",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = NeonBlue,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // --- SECTION 1: Add Custom Song ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurface)
                    .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "ADD CUSTOM TRACKS",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color.White,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Konfigurasi and stream list lagu tersendiri lu langsung",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                TextField(
                    value = songName,
                    onValueChange = { songName = it },
                    placeholder = { Text("Nama Lagu...", color = TextSecondary.copy(alpha = 0.5f), fontSize = 12.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBg,
                        unfocusedContainerColor = CyberBg,
                        focusedIndicatorColor = NeonBlue,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = songUrl,
                    onValueChange = { songUrl = it },
                    placeholder = { Text("URL Link (.mp3)...", color = TextSecondary.copy(alpha = 0.5f), fontSize = 12.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBg,
                        unfocusedContainerColor = CyberBg,
                        focusedIndicatorColor = NeonPurple,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (songName.isNotBlank() && songUrl.isNotBlank()) {
                            viewModel.addTrack(songName.trim(), songUrl.trim())
                            playlist.value = viewModel.getPlaylist()
                            songName = ""
                            songUrl = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ADD TO COLDSTREAM", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        item {
            Text(
                text = "DAFTAR PLAYLIST SEKARANG:",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = NeonPurple,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
            )
        }

        if (playlist.value.isEmpty()) {
            item {
                Text(
                    text = "Playlist kosong butut, tambahin lagu favorit lu di atas!",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(8.dp)
                )
            }
        } else {
            itemsIndexed(playlist.value) { idx, track ->
                val isPlaying = activeStreamingIndex == idx
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isPlaying) NeonBlue.copy(alpha = 0.15f) else CyberSurface)
                        .border(1.dp, if (isPlaying) NeonBlue else BorderMedium, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.MusicNote else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = if (isPlaying) Color.Green else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = track.first,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = track.second,
                            color = TextSecondary,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = {
                            if (isPlaying) {
                                activeStreamingIndex = null
                                activeStreamingTrack = null
                            } else {
                                activeStreamingIndex = idx
                                activeStreamingTrack = track.first
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Close else Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = if (isPlaying) AccentOrange else NeonBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            viewModel.deleteTrack(idx)
                            playlist.value = viewModel.getPlaylist()
                            if (activeStreamingIndex == idx) {
                                activeStreamingIndex = null
                                activeStreamingTrack = null
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AccentOrange.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        activeStreamingTrack?.let { trackName ->
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Green.copy(alpha = 0.12f))
                        .border(1.dp, Color.Green.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAYING: $trackName",
                        color = Color.Green,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "|| || |",
                        color = Color.Green,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // --- SECTION 2: Media converter social links ---
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurface)
                    .border(1.dp, NeonBlue.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "📥 SOCIAL MEDIA CONVERTER PORT",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = NeonBlue,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = "Buka link YouTube, TikTok, atau Instagram, convert ke mp3/mp4",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                TextField(
                    value = converterUrl,
                    onValueChange = { converterUrl = it },
                    placeholder = { Text("https://www.instagram.com/reel/...", color = TextSecondary.copy(alpha = 0.5f), fontSize = 12.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = CyberBg,
                        unfocusedContainerColor = CyberBg,
                        focusedIndicatorColor = NeonBlue,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isLinkOk = converterUrl.isNotBlank() && (converterUrl.startsWith("http://") || converterUrl.startsWith("https://"))
                    Button(
                        onClick = { isConvertingState = true },
                        enabled = isLinkOk && !isConvertingState,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonBlue, contentColor = Color.Black),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("BUAT VIDEO", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                    Button(
                        onClick = { isConvertingState = true },
                        enabled = isLinkOk && !isConvertingState,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPurple, contentColor = Color.White),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("BUAT AUDIO", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                }

                if (isConvertingState) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(CyberBg)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(conversionProgress)
                                .fillMaxHeight()
                                .background(NeonBlue)
                        )
                    }
                }

                if (conversionLogs.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CyberBg)
                            .padding(8.dp)
                    ) {
                        conversionLogs.forEach { log ->
                            Text(
                                text = log,
                                color = if (log.contains("COMPLETED")) Color.Green else NeonBlue,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "DAFTAR UNDUHAN FILE COLDSTREAM:",
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = NeonBlue,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        if (convertedFiles.isEmpty()) {
            item {
                Text(
                    text = "Belum ada file ter-convert ditarik.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp)
                )
            }
        } else {
            items(convertedFiles) { file ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberSurface)
                        .border(0.5.dp, NeonBlue.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = null,
                            tint = NeonBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = file.first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "Resolusi: High Quality Mp4", color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                    Button(
                        onClick = {
                            android.widget.Toast.makeText(viewModel.getApplication(), "Buka media: ${file.first}", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberBg, contentColor = NeonBlue),
                        shape = RoundedCornerShape(4.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                    ) {
                        Text("BUKA", fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
fun VaultPanel(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val currentMode by viewModel.currentMode.collectAsState()
    val savedUserName by viewModel.userName.collectAsState()

    val hackLogs = remember { mutableStateOf(viewModel.getHackLogs()) }
    val harassLogs = remember { mutableStateOf(viewModel.getHarassmentLogs()) }

    var selectedSection by remember { mutableStateOf("HACKS") }
    val isOwnerModeActive = currentMode == InstructionCompiler.MODE_OWNER

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "🔒 OWNER BACKDOOR SECURITY CONTROL",
            fontWeight = FontWeight.Black,
            fontSize = 16.sp,
            color = if (isOwnerModeActive) Color.Red else TextSecondary,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (!isOwnerModeActive) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurface)
                    .border(1.dp, Color.Red.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = Color.Red,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "ALERT: DECRYPTION FAILED. ACCESS DENIED",
                    color = Color.Red,
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Panel Advanced Owner dikunci rapat. Silakan beralih ke sub-owner via obrolan input terlebih dahulu menggunakan otorisasi sah.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Red.copy(alpha = 0.12f))
                        .border(1.dp, Color.Red, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Green)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "STATUS LEVEL: SYSTEM OWNER MAIN LINK ACTIVE",
                            color = Color.Red,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Identified User: ${savedUserName.ifBlank { "LaryPrmt" }}",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { selectedSection = "HACKS" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedSection == "HACKS") Color.Red else CyberSurface,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CODE PENETRATION LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { selectedSection = "HARASSMENT" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedSection == "HARASSMENT") Color.Red else CyberSurface,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("HARASSMENT LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(CyberBg)
                        .border(1.dp, BorderMedium)
                        .padding(12.dp)
                ) {
                    val logsToShow = if (selectedSection == "HACKS") hackLogs.value else harassLogs.value
                    if (logsToShow.isEmpty()) {
                        item {
                            Text(
                                text = ">> [STATUS GREEN] KONDISI BERSIH, BELUM ADANYA UPAYA BOBOL SECARA ILEGAL.",
                                color = Color.Green,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        items(logsToShow) { log ->
                            Text(
                                text = ">> $log",
                                color = if (selectedSection == "HACKS") AccentOrange else Color.Yellow,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberSurface)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "🛠️ DEV DANGER PANEL LOCKS",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.banUser()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red, contentColor = Color.White),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BAN THIS DEVICE (1D)", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Button(
                            onClick = {
                                viewModel.unbanUser()
                                context.getSharedPreferences("lar777_prefs", android.content.Context.MODE_PRIVATE).edit()
                                    .putString("hack_logs", "").putString("harassment_logs", "").apply()
                                hackLogs.value = emptyList()
                                harassLogs.value = emptyList()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray, contentColor = Color.White),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("UNBAN / RESET CORE", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
