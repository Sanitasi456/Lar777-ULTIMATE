package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Lar777 Sophisticated Dark Cyberpunk Palette
val CyberBg = Color(0xFF050505)       // Ultra deep cosmic dark
val CyberSurface = Color(0xFF111111)  // Elegant dark surface
val BorderDark = Color(0xFF1A1A1A)    // High contrast structural borders
val BorderMedium = Color(0xFF222222)  // Mid-tone dividers
val NeonBlue = Color(0xFF00F0FF)      // Cybernetic Neon Cyan
val NeonPurple = Color(0xFFA855F7)    // Glowing Nebula Violet
val AccentOrange = Color(0xFFFF5500)  // Warning tag orange

val TextPrimary = Color(0xFFF1F1F6)
val TextSecondary = Color(0xFF9E9BAC)
val BotChatBgStart = Color(0xFF1A0033) // Gradient start - Deep Indigo Purple
val BotChatBgEnd = Color(0xFF0A001A)   // Gradient end - Dark void
val UserChatBg = Color(0xFF111111)     // High-contrast clean user slate

// Standard dark theme overrides
val Purple80 = NeonBlue
val PurpleGrey80 = NeonPurple
val Pink80 = AccentOrange

val Purple40 = Color(0xFF0C19B4)
val PurpleGrey40 = Color(0xFF4A154B)
val Pink40 = Color(0xFFFF4500)
