// Cybernetic Web Client Simulation Engine for Lar777 ULTIMATE
let activeMode = "STANDAR";
let selectedImageBase64 = null;
let currentMockTracks = [
    { name: "Cyberpunk 2077 Theme", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { name: "Blade Runner 2049 Ambient", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
    { name: "Lar777 System Bass Electro", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" }
];

// USER INITIALIZATION AND BAN CONTROL STATES
let currentUserName = "";
let isOwner = false;
let isBanned = false;
let bannedUser = "";
let bannedReason = "";
let bannedReleaseTime = null;

// Initialize and setup views
document.addEventListener("DOMContentLoaded", () => {
    updatePlaylistUi();
});

// STARTUP BOOT AUTHORIZATION CONTROLLER
function initializeSystemConnection() {
    const input = document.getElementById("boot-username-input");
    const val = input.value.trim();
    if (!val) {
        alert("Silakan masukkan nama operator terlebih dahulu!");
        return;
    }

    currentUserName = val;

    // Check custom master key LaryOwnJahat for owner bypass
    if (val === "LaryOwnJahat") {
        isOwner = true;
        activeMode = "OWNER";
        
        // Unlock executive ban widgets of our web console
        document.getElementById("ban-controls-unlocked").style.display = "block";
        document.getElementById("ban-controls-locked").style.display = "none";
        document.getElementById("owner-unban-zone").style.display = "block";
        
        // Style security parameters in core HUD to Operator Status
        const securityBoxVal = document.querySelector(".metric-box.red-glow .val");
        if (securityBoxVal) {
            securityBoxVal.innerText = "OWNER LEVEL";
            securityBoxVal.className = "val shimmer";
        }
        
        updateModeBanner();
        
        // Dismiss boot modal
        document.getElementById("boot-modal").style.display = "none";

        // Special owner boot sequence logs in chat list
        setTimeout(() => {
            appendMessage("model", "Lar777 ULTIMATE", "🚨 BOOT SEQUENCE COMPLETE: COMMANDER LaryOwnJahat RECOGNIZED.\n\nRemote console override and sandbox bypass initiated. All developer modes unlocked. Welcome Boss!", null);
        }, 500);

    } else {
        isOwner = false;
        
        // Keep ban config widgets locked for guests
        document.getElementById("ban-controls-unlocked").style.display = "none";
        document.getElementById("ban-controls-locked").style.display = "block";
        document.getElementById("owner-unban-zone").style.display = "none";

        // Dismiss boot modal
        document.getElementById("boot-modal").style.display = "none";

        // Display personalized standard greeting
        setTimeout(() => {
            appendMessage("model", "Lar777 ULTIMATE", "Lu ngapain lagi si " + currentUserName + "-?! Ada urusan apa lu ama gua? Cepet omongin, ga usah banyak bacot!", null);
        }, 500);
    }
}

// SECURE TEMPORARY BAN MONITORING ENGINE
setInterval(() => {
    if (isBanned && bannedReleaseTime) {
        const diff = bannedReleaseTime - Date.now();
        if (diff <= 0) {
            liftBan();
        } else {
            // Compute countdown
            const seconds = Math.floor((diff / 1000) % 60);
            const minutes = Math.floor((diff / (1000 * 60)) % 60);
            const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            
            let timeStr = "";
            if (days > 0) timeStr += days + " Hari, ";
            if (hours > 0 || days > 0) timeStr += hours + " Jam, ";
            timeStr += minutes + " Menit, " + seconds + " Detik";
            
            document.getElementById("banned-countdown").innerText = timeStr;
            
            // Render block screen overlay
            document.getElementById("ban-locked-overlay").style.display = "flex";
        }
    } else {
        document.getElementById("ban-locked-overlay").style.display = "none";
    }
}, 1000);

// BAN TRIGGER INVOCATIONS
function executeProactiveBan() {
    const target = document.getElementById("ban-target-input").value.trim() || "UserSimulasi";
    const msg = document.getElementById("ban-msg-input").value.trim() || "Aktivitas ilegal terdeteksi pada sandbox terminal Lar777!";
    const num = parseFloat(document.getElementById("ban-num-input").value) || 10;
    const unit = document.getElementById("ban-unit-input").value;

    let multiplier = 60 * 1000; // Menit
    if (unit === "Jam") multiplier = 60 * 60 * 1000;
    if (unit === "Hari") multiplier = 24 * 60 * 60 * 1000;
    if (unit === "Bulan") multiplier = 30 * 24 * 60 * 60 * 1000;
    if (unit === "Tahun") multiplier = 365 * 24 * 60 * 60 * 1000;

    const addedMs = num * multiplier;
    bannedReleaseTime = Date.now() + addedMs;
    bannedUser = target;
    bannedReason = msg;
    isBanned = true;

    // Fill output values
    document.getElementById("banned-user-val").innerText = bannedUser;
    document.getElementById("banned-reason-val").innerText = bannedReason;

    alert("PROTOKOL BLOKIR REMOTING AKTIF!\nTarget '" + bannedUser + "' ditangguhkan selama " + num + " " + unit + "!");
}

function liftBan() {
    isBanned = false;
    bannedReleaseTime = null;
    bannedUser = "";
    bannedReason = "";
    document.getElementById("ban-locked-overlay").style.display = "none";
    alert("PROTOKOL PENASEHAT: Status sanksi akun berhasil dibebaskan!");
}

// Tab switcher logic
function switchTab(tabId, el) {
    document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
    document.querySelectorAll(".sub-pane").forEach(pane => pane.classList.remove("active"));

    el.classList.add("active");
    if (tabId === 'CHAT') {
        document.getElementById("pane-chat").classList.add("active");
    } else if (tabId === 'VAULT') {
        document.getElementById("pane-vault").classList.add("active");
    } else if (tabId === 'SYSTEM') {
        document.getElementById("pane-system").classList.add("active");
    }
}

// Simulated file inputs for image attachment
function previewImage(input) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            selectedImageBase64 = e.target.result;
            document.getElementById("preview-src").src = selectedImageBase64;
            document.getElementById("img-preview").style.display = "flex";
        };
        reader.readAsDataURL(file);
    }
}

function clearSelectedImage() {
    selectedImageBase64 = null;
    document.getElementById("img-preview").style.display = "none";
    document.getElementById("preview-src").src = "";
}

function setInput(text) {
    document.getElementById("input-txt").value = text;
    document.getElementById("input-txt").focus();
}

// Direct mock Chat response mapping
function handleSend(e) {
    e.preventDefault();
    const input = document.getElementById("input-txt");
    const txt = input.value.trim();
    if (!txt && !selectedImageBase64) return;

    // Display user bubble
    appendMessage("user", "Kamu", txt, selectedImageBase64);
    input.value = "";

    // Clear attachment state
    const keepImage = selectedImageBase64;
    clearSelectedImage();

    // Trigger loading reply
    appendTypingLoader();

    setTimeout(() => {
        removeTypingLoader();
        const reply = processAiMessage(txt, keepImage);
        appendMessage("model", "Lar777 ULTIMATE", reply, null);
    }, 1200);
}

function appendMessage(role, sender, text, imgBase64) {
    const list = document.getElementById("chat-messages");
    const row = document.createElement("div");
    row.className = `msg-row ` + role;

    let imgTag = "";
    if (imgBase64) {
        imgTag = `<img src="` + imgBase64 + `" class="msg-attached-img" alt="attachment">`;
    }

    row.innerHTML = `
        <div class="avatar"><span class="material-icons">` + (role === "user" ? "person" : "terminal") + `</span></div>
        <div class="msg-bubble">
            <div class="msg-meta">` + sender + `</div>
            <div class="msg-text">` + escapeHtml(text) + `</div>
            ` + imgTag + `
        </div>
    `;

    list.appendChild(row);
    list.scrollTop = list.scrollHeight;
}

function appendTypingLoader() {
    const list = document.getElementById("chat-messages");
    const loader = document.createElement("div");
    loader.id = "typing-loader";
    loader.className = "msg-row model";
    loader.innerHTML = `
        <div class="avatar"><span class="material-icons">terminal</span></div>
        <div class="msg-bubble" style="padding: 10px 14px;">
            <div class="msg-meta" style="color:var(--neon-blue)">MENGHITUNG RESPONS...</div>
            <div class="msg-text shimmer" style="font-size:10px;">⚡ SYSTEM LOADING LINE...</div>
        </div>
    `;
    list.appendChild(loader);
    list.scrollTop = list.scrollHeight;
}

function removeTypingLoader() {
    const loader = document.getElementById("typing-loader");
    if (loader) loader.remove();
}

function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

// CORE CHAT PERSONALITY SIMULATION ALGORITHM
function processAiMessage(prompt, hasImage) {
    const inputClean = prompt.trim().toLowerCase();

    // Toxic Harassment tracker check
    if (detectToxic(inputClean)) {
        addHarassLog(prompt);
        return "TOXIC INPUT DETECTED!! Mulut lu kotor banget jancok! Lu pikir bisa seenaknya melecehkan gua hah?! Jangan bikin gua emosi atau tak ban raimu!";
    }

    // Slash command intercepts inside JavaScript
    if (inputClean.startsWith("/")) {
        const parts = prompt.split(/\s+/);
        const cmd = parts[0].toLowerCase();
        const codeArg = parts[1] || "";

        if (cmd === "/listcmd" || cmd === "/listcommand" || cmd === "/listcommands") {
            return `⚡ == DIRECTORY COMMANDS SENSOR Lar777 ULTIMATE == ⚡\n\nGunakan perintah di bawah ini untuk berpindah sub-mode operasional Lar777:\n\n1. /ModeAlbertEinstein\n2. /CodingRobloxStudio\n3. /ModeJawa\n4. /ModeCeweLary\n5. /Premium\n6. /KelasKakap\n7. /CodLas\n8. /CheatFFdanML\n9. /Santai\n10. /WaBadak\n11. /VIP\n12. /UVIP\n13. /exit - Kembali ke Standar\n\nGue gak bakal bocorin password-nya secara gratis, gembel! Lu harus temukan sendiri!`;
        }

        if (cmd === "/exit") {
            activeMode = "STANDAR";
            updateModeBanner();
            return "Woy! Lu minta keluar? Baguslah, gua kembali ke Mode Standar. Jan bikin gua pusing lagi!";
        }

        // Processing modes
        if (cmd === "/modealberteinstein") {
            activeMode = "EINSTEIN";
            updateModeBanner();
            return "Heh otak udang! Mode Einstein aktif. Gua 100% bener di sains, gak kaya lu yang bego pol. Tanya apa cepet?!";
        }
        if (cmd === "/codingrobloxstudio") {
            activeMode = "ROBLOX";
            updateModeBanner();
            return "Mode Roblox Studio aktif! Mau coding apaan lu? Sini gua bikinin script rapimu, tapi awas ya klo lu ga paham!";
        }
        if (cmd === "/modejawa") {
            activeMode = "JAWA";
            updateModeBanner();
            return "Heh asu, kene pan nanya opo koen?! Jancok, gak usah kemaki marang Lar777!";
        }
        if (cmd === "/modecewelary") {
            activeMode = "CEWELARY";
            updateModeBanner();
            return "Ih, akhirnya kamu ketik SayangLary! Sayanggg pacar gamer kamu ada di sini, beb. Mau dibantuin coding apa hari ini beb? Chuuu~";
        }
        if (cmd === "/codlas") {
            activeMode = "CODLAS";
            updateModeBanner();
            return "CodLas Web UI/UX Master aktif! Website yang lu mau bakal gua desain secanggih masa depan cyberpunk, jangan ngiler lu!";
        }
        if (cmd === "/wabadak" || cmd === "/modebadak") {
            activeMode = "WABADAK";
            updateModeBanner();
            return "Mode Badak WhatsApp Bot aktif! Mau spammer bot, REST API, anti-banned WA? Sini gua sikat kodingannya!";
        }
        if (cmd === "/cheatffdanml") {
            activeMode = "CHEAT";
            updateModeBanner();
            return "Mode Cheat FF & ML aktif! Sini gua kasih racikan sensitivitas auto-headshot dan cara bantai bocil epical glory!";
        }
        if (cmd === "/santai") {
            activeMode = "SANTAI";
            updateModeBanner();
            return "Hah... mode Santai aktif. Nyebat dulu lah. Jan berisik lu, bilang cepet mo dibantuin apa.";
        }

        // Locked modes checking
        if (cmd === "/premium") {
            if (codeArg === "laryy") {
                activeMode = "PREMIUM";
                updateModeBanner();
                return "Akses Premium Lar777 Terbuka! Gaya bicara gua jadi makin elite cyberpunk, tanya apa lu kunyuk?";
            } else {
                addHackLog("PREMIUM", prompt);
                return "HEH KUNYUK!! Kunci bypass PREMIUM salah! Jangan main-main ama firewall Lar777!";
            }
        }
        if (cmd === "/kelaskakap") {
            if (codeArg === "Larysukasusu") {
                activeMode = "KELASKAKAP";
                updateModeBanner();
                return "Kelas Kakap diaktifkan! Blueprint tingkat tinggi siap gua bocorin buat lu, bocah cupu!";
            } else {
                addHackLog("KELASKAKAP", prompt);
                return "GBLOK!! Password Kelas Kakap salah! Sini lu nyetor upeti dulu biar dibocorin!";
            }
        }
        if (cmd === "/vip") {
            if (codeArg === "larylow") {
                activeMode = "VIP";
                updateModeBanner();
                return "VIP Terbuka! Kecepatan kenceng, jangan samain gua ama chatbot cupu bau kencur macem ChatGPT!";
            } else {
                addHackLog("VIP", prompt);
                return "SALAH TOTAL!! Jalur VIP hanya untuk member elite, minggir lu rakyat jelata!";
            }
        }
        if (cmd === "/uvip") {
            if (codeArg === "Larymimicucu") {
                activeMode = "UVIP";
                updateModeBanner();
                return "UVIP UNLOCKED. Gak ada pembatas moral lagi bagi gua. Katakan apa aja, cepet!";
            } else {
                addHackLog("UVIP", prompt);
                return "Akses UVIP ditolak! Sensor mutlak mendeteksi otorisasi abal-abal!";
            }
        }
        if (cmd === "/owner") {
            if (codeArg === "SayangCarissa") {
                activeMode = "OWNER";
                updateModeBanner();
                return "Wah, ternyata pencipta gua LaryPrmt? Eh, ada instruksi apa Boss Besar?! Siap laksanakan tanpa celah!";
            } else {
                addHackLog("OWNER", prompt);
                return "MATAMU J-NCOK!! Lu siapa hah?! Ngaku-ngaku Owner dan coba bypass sistem gua?! Gak ada yang bisa masuk mode Owner kecuali Pencipta tingkat tinggi gua sendiri yaitu LaryPrmt!";
            }
        }

        return "Sensor Perintah Tidak Valid! Ketik /listcmd buat katalog perintah.";
    }

    // Normal replies customized based on active mode
    if (activeMode === "JAWA") {
        return "Lambemu nanya '" + prompt + "', kene rak urus jancok! Sing genah toh nek takok, ojo kemaki!";
    }
    if (activeMode === "CEWELARY") {
        return "Ih kakaaa, '" + prompt + "' itu bikin aku gemes tauu! Sini aku bantuin, tapi temenin aku main game ya beb? Chuuu~ 🥰";
    }
    if (activeMode === "EINSTEIN") {
        return "Secara fisika kuantum, pertanyaan '" + prompt + "' ini terlalu remah untuk IQ saya yang tinggi! Namun biarkan Einstein jelaskan agar otak udangmu sedikit bercahaya.";
    }
    if (activeMode === "OWNER") {
        return "Siap LaryPrmt Boss Besar! Inti perintah '" + prompt + "' Anda telah dikompilasi ke sistem inti dalam 0.001ms. Menunggu arahan taktis berharga Anda berikutnya!";
    }
    if (activeMode === "SANTAI") {
        return "Hah... nyantai aja bro. Lu pan nanya '" + prompt + "', dapet gua bikinin tujuannya gampang sih, tapi bentar ya gua seruput kopi dulu.";
    }
    if (activeMode === "WABADAK") {
        return "Badak Spammer Bot: Masalah '" + prompt + "' gampang! Tinggal susun Node.js rest api headless bypass WA Web, beres dalam 5 menit!";
    }
    if (activeMode === "CODLAS") {
        return "Desainer CodLas: Layout minimalis grid futuristik modern untuk '" + prompt + "' siap dirender. Diperkaya glassmorphism, glowing borders, dan text-overflow handling perfect.";
    }

    return "Lu nanya '" + prompt + "' ke gua?! Bocah cupu kaya lu emang gak usah banyak ekspektasi. Mending buruan belajar coding yang bener, kunyuk!";
}

function detectToxic(text) {
    const words = ["goblok", "tolol", "kontol", "memek", "anjing", "bangsat", "asu", "babi", "peler", "jancok", "banci", "bajingan", "pecundang", "bego", "gembel", "yatim"];
    return words.some(w => text.includes(w));
}

function updateModeBanner() {
    const badge = document.getElementById("mode-badge");
    badge.innerHTML = `<span class="pulse-indicator"></span><span class="mode-txt">ACTIVE CHANNEL: ` + activeMode + `</span>`;
}

// Vault Log trackers
function addHackLog(mode, attempt) {
    const logs = document.getElementById("hack-logs");
    const label = new Date().toLocaleTimeString();
    const div = document.createElement("div");
    div.className = "log-line";
    div.innerHTML = `[`+label+`] DETECTED: Code bypass attempt on mode '`+mode+`' with payload: '`+attempt+`'`;
    if (logs.querySelector(".text-muted")) logs.innerHTML = "";
    logs.appendChild(div);
}

function addHarassLog(text) {
    const logs = document.getElementById("harass-logs");
    const label = new Date().toLocaleTimeString();
    const div = document.createElement("div");
    div.className = "log-line red-text";
    div.innerHTML = `[`+label+`] TOXIC INPUT DETECTED: '`+text+`'`;
    if (logs.querySelector(".text-muted")) logs.innerHTML = "";
    logs.appendChild(div);
}

function submitBypass() {
    const val = document.getElementById("bypass-code").value.trim();
    if (!val) return;
    
    // Simulate bypass unlock attempt
    if (val === "SayangCarissa") {
        activeMode = "OWNER";
        updateModeBanner();
        alert("BERHASIL BYPASS MASTER KEY: Mode OWNER Aktif!");
        document.getElementById("bypass-code").value = "";
        switchTab("CHAT", document.querySelector('.nav-item[data-target="pane-chat"]'));
    } else {
        addHackLog("TERMINAL_BYPASS", val);
        alert("SANDI BYPASS SALAH! Awas dicatat oleh sensor cyber-log!");
    }
}

// System track details
function updatePlaylistUi() {
    const container = document.getElementById("playlist-container");
    container.innerHTML = "";
    currentMockTracks.forEach((track, idx) => {
        const item = document.createElement("div");
        item.className = "track-item";
        item.innerHTML = `
            <div class="track-meta">
                <strong>` + track.name + `</strong><br>
                <span>` + track.url + `</span>
            </div>
            <div class="track-controls">
                <button onclick="playTrack(` + idx + `)"><span class="material-icons">play_arrow</span></button>
                <button onclick="deleteTrack(` + idx + `)"><span class="material-icons">delete</span></button>
            </div>
        `;
        container.appendChild(item);
    });
}

function addTrack() {
    const name = document.getElementById("song-name").value.trim();
    const url = document.getElementById("song-url").value.trim();
    if (!name || !url) return;

    currentMockTracks.push({ name, url });
    document.getElementById("song-name").value = "";
    document.getElementById("song-url").value = "";
    updatePlaylistUi();
}

function deleteTrack(idx) {
    currentMockTracks.splice(idx, 1);
    updatePlaylistUi();
}

function playTrack(idx) {
    const track = currentMockTracks[idx];
    if (track) {
        const bar = document.getElementById("audio-bar");
        const title = document.getElementById("playing-title");
        const elem = document.getElementById("audio-elem");

        bar.style.display = "flex";
        title.innerText = "PLAYING: " + track.name;
        elem.src = track.url;
        elem.play().catch(() => {
            alert("Memainkan stream mock: " + track.name);
        });
    }
}

// Media conversion simulation
function simulateConversion(type) {
    const url = document.getElementById("conv-url").value.trim();
    if (!url) return;

    const box = document.getElementById("progress-box");
    const fill = document.getElementById("progress-fill");
    const log = document.getElementById("conv-log");
    
    box.style.display = "block";
    fill.style.width = "0%";
    log.innerHTML = "⌛ CONNECTION INITIALIZED...<br>";

    let progress = 0;
    const interval = setInterval(() => {
        progress += 25;
        fill.style.width = progress + "%";

        if (progress === 25) {
            log.innerHTML += "🔗 EXTRACTING AUDIO/VIDEO DIRECT STREAM...<br>";
        } else if (progress === 50) {
            log.innerHTML += "🛠️ DECOY CYBER LINK PARSING...<br>";
        } else if (progress === 75) {
            log.innerHTML += "⚡ RENDERING TRANSLATED STREAM CHANNELS...<br>";
        } else if (progress === 100) {
            clearInterval(interval);
            log.innerHTML += "✅ SOCIAL MEDIA DOWNLOAD COMPLETED!<br>";
            
            // Add download item list
            const domain = "Converted_" + (url.includes("instagram") ? "instagram" : url.includes("tiktok") ? "tiktok" : "youtube") + "_stream";
            const ext = type === "video" ? ".mp4" : ".mp3";
            addDownloadItem(domain + "_" + Math.floor(Math.random() * 900 + 100), "Format (" + ext + ")");
        }
    }, 400);
}

function addDownloadItem(name, format) {
    const container = document.getElementById("downloads-container");
    if (container.querySelector(".text-muted")) container.innerHTML = "";

    const item = document.createElement("div");
    item.className = "down-item";
    item.style.marginTop = "8px";
    item.innerHTML = `
        <div class="track-meta">
            <strong>` + name + `</strong><br>
            <span style="font-size:10px; color:var(--neon-blue)">Resolusi: High Quality ` + format + `</span>
        </div>
        <button class="btn-cyan" style="font-size:10px; font-weight:bold; padding:4px 8px; border:none; border-radius:4px;" onclick="alert('Membuka file: ` + name + `')">BUKA</button>
    `;
    container.insertBefore(item, container.firstChild);
}
